# Knight's Tour Problem

## 1. Problem Description

### 1.1 Introduction
The Knight's Tour is a classic chess-based algorithmic challenge where a knight must navigate a chessboard, visiting every square exactly once, using only the knight's unique L-shaped movement.

### 1.2 Scenario Visualization

#### Chessboard Representation
```
Initial Board (5x5):
 -1 -1 -1 -1 -1
 -1 -1 -1 -1 -1
 -1 -1 0 -1 -1
 -1 -1 -1 -1 -1
 -1 -1 -1 -1 -1

Solved Board (5x5 Example):
  0 3 6 13 16
 17 12 1 4 7
  2 15 18 9 14
 11 8 19 20 5
 24 21 10 23 22
```

### 1.3 Real-World Analogies
- Path planning for autonomous robots
- Optimization routing problems
- Computational problem-solving techniques

## 2. Problem Formulation

### 2.1 State Representation
- **Board**: 2D grid representing the chessboard
- **State Variables**:
  - Current knight position (x, y)
  - Visited squares tracking
  - Move count

### 2.2 Action Space Definition
**Knight's Possible Moves**:
- 8 unique L-shaped movements
- Coordinate offsets:
  ```python
  moves = [
      (2, 1), # Right-up
      (1, 2), # Up-right
      (-1, 2), # Up-left
      (-2, 1), # Left-up
      (-2, -1), # Left-down
      (-1, -2), # Down-left
      (1, -2), # Down-right
      (2, -1) # Right-down
  ]
  ```

### 2.3 Goal State Description
- Visit every square exactly once
- Complete a tour of N² moves (N = board size)
- Two possible tour types:
  1. **Open Tour**: No return to start
  2. **Closed Tour**: Can return to starting square

### 2.4 Constraints and Limitations
- **Movement Rules**:
  - Only L-shaped moves
  - Stay within board boundaries
  - No square visited twice
- **Computational Constraints**:
  - Time complexity grows exponentially
  - Practical for smaller board sizes (5x5 to 8x8)
  - Memory limitations

## 3. Proposed Solution

### 3.1 Chosen Algorithm: Backtracking

#### Why Backtracking?
1. **Systematic Exploration**
   - Methodically tries all possible paths
   - Efficiently abandons unsuccessful routes

2. **Recursive Problem-Solving**
   - Natural fit for tour construction
   - Incrementally builds solution

3. **Educational Value**
   - Demonstrates fundamental search techniques
   - Illustrates recursive algorithm design

### 3.2 Algorithm Workflow
```
1. Start at initial square
2. Mark square as visited
3. Select possible knight moves
4. Recursively explore moves
5. If no solution:
   - Backtrack
   - Reset visited status
   - Try alternative path
6. Repeat until tour completed or all paths exhausted
```
### 3.3 Pseudo-Algorithm
```python
def solve_knights_tour(board):
    # Initialize board
    # Select starting position
    # Recursive exploration
    # - Try all possible moves
    # - Backtrack if path fails
    # Return completed tour
```

## 4. Implementation Highlights

### 4.1 Key Components
- Recursive tour construction
- Move validation
- Backtracking mechanism

### 4.2 Potential Improvements
- Warnsdorff's heuristic
- Move ordering optimization
- Parallel search strategies
