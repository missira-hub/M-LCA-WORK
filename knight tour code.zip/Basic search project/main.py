from src.state import KnightState
from src.search import KnightTourSolver
from src.visualization import KnightTourVisualizer

def main():
    # Set board size
    board_size = 5
    
    # Create solver and find solution
    solver = KnightTourSolver(board_size)
    solution = solver.solve()
    
    if solution:
        print("Solution found!")
        # Display the solution
        visualizer = KnightTourVisualizer(solution)
        visualizer.display_solution()
    else:
        print("No solution exists for the given board size.")

if __name__ == "__main__":
    main()