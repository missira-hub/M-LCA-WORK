import matplotlib.pyplot as plt
import numpy as np

class KnightTourVisualizer:
    """Handles visualization of the Knight's Tour solution."""
    
    def __init__(self, state):
        self.state = state
        
    def display_solution(self):
        """Display the complete solution path."""
        fig, ax = plt.subplots(figsize=(10, 10))
        
        # Create the chessboard pattern
        board = np.zeros((self.state.size, self.state.size))
        for i in range(self.state.size):
            for j in range(self.state.size):
                if (i + j) % 2 == 0:
                    board[i, j] = 1
                    
        # Display the board
        ax.imshow(board, cmap='gray')
        
        # Add move numbers
        for i in range(self.state.size):
            for j in range(self.state.size):
                if self.state.board[i][j] != -1:
                    ax.text(j, i, str(self.state.board[i][j]),
                           ha='center', va='center',
                           color='red' if board[i, j] == 1 else 'blue')
        
        # Add grid
        ax.grid(True)
        ax.set_title("Knight's Tour Solution")
        plt.show()
