class KnightState:
    """Represents a state in the Knight's Tour problem."""
    
    def __init__(self, size):
        """
        Initialize the knight's tour state.
        
        Args:
            size (int): Size of the chess board
        """
        self.size = size
        self.board = [[-1] * size for _ in range(size)]
        self.current_pos = (0, 0)
        self.move_count = 0
        self.moves = [
            (2, 1), (1, 2), (-1, 2), (-2, 1),
            (-2, -1), (-1, -2), (1, -2), (2, -1)
        ]
    
    def get_valid_moves(self):
        """Generate all valid moves from current position."""
        valid_moves = []
        x, y = self.current_pos
        
        for dx, dy in self.moves:
            next_x, next_y = x + dx, y + dy
            if self.is_valid_position(next_x, next_y):
                valid_moves.append((next_x, next_y))
        
        return valid_moves
    
    def is_valid_position(self, x, y):
        """Check if position is valid and unvisited."""
        return (0 <= x < self.size and 
                0 <= y < self.size and 
                self.board[x][y] == -1)
    
    def make_move(self, next_pos):
        """Make a move to the next position."""
        x, y = next_pos
        self.board[x][y] = self.move_count
        self.current_pos = next_pos
        self.move_count += 1
    
    def undo_move(self, pos):
        """Undo a move (for backtracking)."""
        x, y = pos
        self.board[x][y] = -1
        self.move_count -= 1
    
    def is_goal(self):
        """Check if current state is a goal state."""
        return self.move_count == self.size * self.size
    
    def copy(self):
        """Create a deep copy of the current state."""
        new_state = KnightState(self.size)
        new_state.board = [row[:] for row in self.board]
        new_state.current_pos = self.current_pos
        new_state.move_count = self.move_count
        return new_state
