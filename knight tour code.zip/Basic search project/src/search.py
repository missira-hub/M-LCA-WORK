from .state import KnightState  # Add this import at the top


class KnightTourSolver:
    """Implements the backtracking search algorithm for Knight's Tour."""
    
    def __init__(self, size):
        self.size = size
        self.state = KnightState(size)
    
    def solve(self):
        """
        Solve the Knight's Tour using backtracking.
        Returns the solution state if found, None otherwise.
        """
        # Mark the starting position
        self.state.board[0][0] = 0
        
        if self._solve_recursive(0, 0, 1):
            return self.state
        return None
    
    def _solve_recursive(self, x, y, move_count):
        """Recursive helper for solving the Knight's Tour."""
        if move_count == self.size * self.size:
            return True
            
        for next_x, next_y in self.state.get_valid_moves():
            self.state.make_move((next_x, next_y))
            
            if self._solve_recursive(next_x, next_y, move_count + 1):
                return True
                
            self.state.undo_move((next_x, next_y))
        
        return False
